# Example Importable Indicator Enricher

Installable sample package for CyberForge Plugin Manager. It reads only the JSON context passed for explicitly granted capabilities and returns a JSON proposal. It does not write findings or make network requests.

Runtime: `python:3.12-alpine`. Docker/Podman and this image must already exist locally; CyberForge will not pull the image.

After import, the plugin remains disabled with no permission grants. Review the code and choose only the capabilities it needs before enabling it.
